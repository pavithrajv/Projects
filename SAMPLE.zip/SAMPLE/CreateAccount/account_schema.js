const { buildSchema } = require('graphql');

module.exports = buildSchema(`

    type Query {
        accounts: [Account]        
      }

      type Account{
        account_id: String
        account_name: String
      }

      input AccountInput{
        account_id: String
        account_name: String
        sbu_id: String
        sbu_name: String
        total_no_of_pods: Int
      }

      input AccountInputUpdate{
        account_id: String
        account_name: String
        sbu_id: String
        sbu_name: String
      }

      type msgResponse{
          message:String,
          status:String
      }

      type Mutation {
        createAccount(accountInput:AccountInput): msgResponse!
        deleteAccount(account_id: String):msgResponse!
        updateAccount(accountInputUpdate: AccountInputUpdate): msgResponse!
      }

      schema {
        query: Query
        mutation: Mutation
      }

`);