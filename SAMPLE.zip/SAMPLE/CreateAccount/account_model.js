const mongoose = require('mongoose');
const Schema = mongoose.Schema;
    
const accountScheme = new Schema({

    account_id: {
        type: String,
        required: false
    },
    account_name: {
        type: String,
        required: false
    },
    sbu_id: {
        type: String,
        required: true
    },
    sbu_name: {
        type: String,
        required: true
    },
    total_no_of_pods: {
        type: Number,
        required: true
    }
});

module.exports = mongoose.model('Account', accountScheme);
