const Account = require('./account_model');
console.log("mutation resolver")

async function update_funct(args, to_change) {
    console.log("inside update_funct");
    var accountid = { account_id: args };
    var temp = await Account.findOneAndUpdate(accountid, { $set: to_change }, { returnOriginal: true }, function (err, res) {
        if (err) { console.log('error query'); }
    });

}

module.exports = {
     
    //creates a new account
    
    createAccount: async (args) => {
        let msgResponse = null;

        const account = new Account({
            account_id : args.accountInput.account_id,
            account_name : args.accountInput.account_name,
            sbu_id : args.accountInput.sbu_id,
            sbu_name : args.accountInput.sbu_name,
            total_no_of_pods : args.accountInput.total_no_of_pods
        });

        if(account.account_id == null || account.account_name == null){
            msgResponse = {
            message: "Account cannot be created as the account_id/account_name is null",
            status: "fail"
        }
        return msgResponse;
        }

        const res = await Account.findOne({ account_id: account.account_id });
        if(res){
            msgResponse = {
            message: "Account cannot be created as the account_id already exixts in database",
            status: "fail"
            }
        }
        else{
        const res = await account.save();
        msgResponse = {
            message: "Account created",
            status: "success"
            }
        }  
        return msgResponse;
        
    },  

    //deletes an account
    
    deleteAccount: async (args) => {
        let msgResponse = null
        const account = await Account.findOne({ account_id: args.account_id });
        if (!account) {
            
            msgResponse = {
                message: "Account doesn't exists",
                status: "fail"
            }
            return msgResponse;
        }
        else{
            const delAccount = await Account.deleteOne({ account_id: args.account_id });
            msgResponse = {
                message: "Account deleted",
                status: "success"
            }
            return msgResponse;
        }
         
    },

        
    //updates an account
    updateAccount: async (args) => {
        var regex = new RegExp("^\\s*$");
        let msgResponse = null

        const account = await Account.findOne({ account_id: args.accountInputUpdate.account_id });

        if(args.accountInputUpdate.account_id == null || args.accountInputUpdate.account_name == null){
            msgResponse = {
            message: "Account cannot be updated as the account_id/account_name is null",
            status: "fail"
        }
        return msgResponse;
        }

        //if account desnt exist
        if (account == null) {
            
            msgResponse = {
                message: "Account doesn't exists",
                status: "fail"
            }
            return msgResponse;
        }

        //if account exits
        else{
            if (!regex.test(args.accountInputUpdate.account_name) && (args.accountInputUpdate.account_name != null)) {
                var to_change = { account_name: args.accountInputUpdate.account_name };
                update_funct(args.accountInputUpdate.account_id, to_change); 
            }

            //SBU_ID
            if (!regex.test(args.accountInputUpdate.sbu_id) && (args.accountInputUpdate.sbu_id != null)) {
                var to_change = { sbu_id: args.accountInputUpdate.sbu_id };
                update_funct(args.accountInputUpdate.account_id, to_change);    
            }

            //SBU_NAME
            if (!regex.test(args.accountInputUpdate.sbu_name) && (args.accountInputUpdate.sbu_name != null)) {
                var to_change = { sbu_name: args.accountInputUpdate.sbu_name };
                update_funct(args.accountInputUpdate.account_id, to_change); 
            }

             msgResponse = {
                message: "Account updated",
                status: "success"
            }
        }

        return msgResponse;
    }
}   