const Account = require('./account_model');

module.exports = {

    //displays all accounts in the database
    accounts: async () => { 
        const accounts = await Account.find();
        return accounts;
    }
   
};