const mongoose = require('mongoose');
const config = require('../config');
let CreateMongoConnection =()=>{
    return mongoose.connect(config.mongoUrl, { useNewUrlParser: true });
}
module.exports = {CreateMongoConnection}
