let config = require('./config');
let DB = require('./DB');
const mongoose = require('mongoose');
const express = require('express');
const bodyParser = require('body-parser');
const graphqlHttp = require('express-graphql');

//all imports for createAccount--------------------------------------------------------------  
const graphQlAccountSchema = require('./CreateAccount/account_schema');
const accountQueryResolver = require('./CreateAccount/query_resolver');
const accountMutationResolver = require('./CreateAccount/mutation_resolver');
//---------------------------------------------------------------------------------

const index = express();



index.use(bodyParser.json());
index.use(bodyParser.urlencoded({ extended: true }));

index.use('/graphql', express.static('public'))


index.use(
  '/graphql',
  graphqlHttp({
    schema: graphQlAccountSchema,

    rootValue: {
      ...accountQueryResolver,
      ...accountMutationResolver
    },
    graphiql: true,
    tracing: true
  })
)  

DB.CreateMongoConnection().then(res => {
  index.listen(config.port, () => {
    //logger.info("Listening @ :", config.port);
    console.log("Listening @ :", config.port);
 });
}, err => {
  logger.error("Error creating DB connection");
  console.log(err);
})