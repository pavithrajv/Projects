module.exports={
    port: process.env.Port || 3005,
    mongoUrl:"mongodb://localhost:27017/sample",
    
}

