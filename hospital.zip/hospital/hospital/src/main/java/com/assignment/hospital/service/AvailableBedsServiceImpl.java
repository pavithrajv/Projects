package com.assignment.hospital.service;

import com.assignment.hospital.resource.model.HospitalDetails;
import com.assignment.hospital.resource.model.Patients;
import com.assignment.hospital.exception.BedsNotAvailableException;
import com.assignment.hospital.exception.DetailsNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class AvailableBedsServiceImpl implements AvailableBedsService {
    @Override
    public int getNoOfBeds(String hospitalName) {

        int count=0;
        int bedcount=0;
        int flag=0;
        List<Patients> patientsList1=new ArrayList<>();
        List<Patients> patientsList2=new ArrayList<>();
        List<Patients> patientsList3=new ArrayList<>();

        List<HospitalDetails> hospitalDetailsList= new ArrayList<>();


        //setting the values of hospital locally
        HospitalDetails hospitalDetails1= new HospitalDetails();
        hospitalDetails1.setId(12);
        hospitalDetails1.setName("aster");
        hospitalDetails1.setBedCount(0);
        Patients patients1= new Patients();
        patients1.setPatientName("akash");
        patients1.setStatus("DISCHARGE");
        patientsList1.add(patients1);
        hospitalDetails1.setPatients(patientsList1);
        hospitalDetailsList.add(hospitalDetails1);

        HospitalDetails hospitalDetails2= new HospitalDetails();
        hospitalDetails2.setName("Childcare");
        hospitalDetails2.setId(13);
        hospitalDetails2.setBedCount(30);
        Patients patients2=new Patients();
        patients2.setPatientName("mehak");
        patients2.setStatus("ADMITTED");
        patientsList2.add(patients2);
        hospitalDetails2.setPatients(patientsList2);
        Patients patients4=new Patients();
        patients4.setPatientName("nivi");
        patients4.setStatus("ADMITTED");
        patientsList2.add(patients4);
        hospitalDetails2.setPatients(patientsList2);
        hospitalDetailsList.add(hospitalDetails2);

        HospitalDetails hospitalDetails3 = new HospitalDetails();
        hospitalDetails3.setName("Vasan");
        hospitalDetails3.setId(14);
        hospitalDetails3.setBedCount(20);
        Patients patients3= new Patients();
        patients3.setPatientName("naveen");
        patients3.setStatus("DISCHARGE");
        patientsList3.add(patients3);
        hospitalDetails3.setPatients(patientsList3);
        Patients patients5=new Patients();
        patients5.setPatientName("karun");
        patients5.setStatus("DISCHARGE");
        patientsList3.add(patients5);
        Patients patients6=new Patients();
        patients6.setPatientName("arul");
        patients6.setStatus("ADMITTED");
        patientsList3.add(patients6);
        hospitalDetails3.setPatients(patientsList3);
        hospitalDetailsList.add(hospitalDetails3);

        for (HospitalDetails hospitalDetails:hospitalDetailsList){
            if (hospitalDetails.getName().equals(hospitalName)){
               flag=1;
                List<Patients> patientsList=hospitalDetails.getPatients();
                for (Patients patients:patientsList) {
                    if (patients.getStatus().equals("ADMITTED")) {
                        count++;
                    }

                }
                bedcount=hospitalDetails.getBedCount()-count;
            }
        }

        if (flag!=1){
            throw new DetailsNotFoundException("Hospital  name not found:    "+hospitalName);
        }

        if (bedcount==0){
            throw new BedsNotAvailableException("Available bed count is:    "+bedcount);
        }
        return bedcount;
    }

    }

