package com.assignment.hospital.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class BedsNotAvailableException extends RuntimeException {

    public BedsNotAvailableException(String excepion){
        super(excepion);
    }
}

