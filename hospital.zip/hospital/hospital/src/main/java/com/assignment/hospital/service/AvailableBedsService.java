package com.assignment.hospital.service;


public interface AvailableBedsService {
   public int getNoOfBeds(String hospitalName);
}
