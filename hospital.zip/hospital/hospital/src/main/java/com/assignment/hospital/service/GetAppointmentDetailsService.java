package com.assignment.hospital.service;

import com.assignment.hospital.resource.model.Appointment;

public interface GetAppointmentDetailsService {
  public Appointment getNewAppointment(String specialistName, String appointmentdDay, String patientName);
}
