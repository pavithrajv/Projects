package com.assignment.hospital.client.model;

import java.util.List;

public class HospitalDetailsRoot {

    private List<HospitalDetails> hospitalDetails;

    public List<HospitalDetails> getHospitalDetails() {
        return hospitalDetails;
    }

    public void setHospitalDetails(List<HospitalDetails> hospitalDetails) {
        this.hospitalDetails = hospitalDetails;
    }
}
