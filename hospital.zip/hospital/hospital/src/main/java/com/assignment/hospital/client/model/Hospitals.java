
package com.assignment.hospital.client.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class Hospitals {

    @JsonProperty("hospital")
    private List<Hospital> hospital = null;

    public List<Hospital> getHospital() {
        return hospital;
    }


    public void setHospital(List<Hospital> hospital) {
        this.hospital = hospital;
    }


}
