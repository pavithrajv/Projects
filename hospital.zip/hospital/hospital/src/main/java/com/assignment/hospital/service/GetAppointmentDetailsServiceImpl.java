package com.assignment.hospital.service;

import com.assignment.hospital.resource.model.Appointment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@PropertySource("classpath:specialist.properties")
public class GetAppointmentDetailsServiceImpl implements GetAppointmentDetailsService {

    @Autowired
   private Environment environment;

    @Override
    public com.assignment.hospital.resource.model.Appointment getNewAppointment(String specialistName, String appointmentdDay, String patientName) {


        String str=specialistName+".details";
        List<String> list= environment.getRequiredProperty(str,List.class);
        Appointment appt=new Appointment();
        appt.setSpecialistName(specialistName);
        appt.setPatientName(patientName);
        String  str1=list.get(0);
        if(str1.contains(appointmentdDay)){
            appt.setAppointmentDay(appointmentdDay);
        }
        appt.setAppointmentTime(list.get(1));

        return appt;
    }
}
