package com.assignment.hospital.resource;

import com.assignment.hospital.resource.model.Appointment;
import com.assignment.hospital.resource.model.Specialist;
import com.assignment.hospital.service.AvailableBedsService;
import com.assignment.hospital.service.GetAppointmentDetailsService;
import com.assignment.hospital.service.HospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class GetHospitalDetailsResource {

    @Autowired
    HospitalService hospitalService;

   @Autowired
    GetAppointmentDetailsService getAppointmentDetailsService;

   @Autowired
    AvailableBedsService availableBedsService;


    //Getting the list of specialists

    @Cacheable(value ="specialistList")
    @RequestMapping(value ="${value}/{name}/{type}",method= RequestMethod.GET, produces={"application/json","application/xml"})
    public List<Specialist> getSpecialistDetails(@PathVariable("name") final String name,@PathVariable("type") final String type){

        List<Specialist> specialistList=hospitalService.getSpecialistDetails(name,type);
        return specialistList;
    }

    //Returning a new Appointment based on specialist available day and time
    @GetMapping("${xyz}/{specialistName}/{appointmentdDay}/{patientName}")
    public Appointment getNewAppointment(@PathVariable("specialistName") final String specialistName,
                                         @PathVariable("appointmentdDay") final String appointmentdDay,
                                         @PathVariable("patientName")final String patientName) {


        return getAppointmentDetailsService.getNewAppointment(specialistName,appointmentdDay,patientName);
    }

    //Getting count of available beds based on patients status
    @GetMapping("${abc}/{hospitalName}")
    public String getNoOfBeds(@PathVariable("hospitalName") final String hospitalName) {

        int bedCount = availableBedsService.getNoOfBeds(hospitalName);
        String str = "Number of beds Available is=" + bedCount;
        return str;
    }



}
