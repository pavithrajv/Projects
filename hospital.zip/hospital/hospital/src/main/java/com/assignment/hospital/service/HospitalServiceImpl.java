package com.assignment.hospital.service;

import com.assignment.hospital.client.HospitalDetailsClient;
import com.assignment.hospital.exception.DetailsNotFoundException;
import com.assignment.hospital.client.model.Hospital;
import com.assignment.hospital.client.model.HospitalRoot;
import com.assignment.hospital.client.model.Hospitals;
import com.assignment.hospital.client.model.Specialist;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class HospitalServiceImpl implements HospitalService {

    @Autowired
    HospitalDetailsClient hospitalDetailsClient;

    @Override
    public  List<com.assignment.hospital.resource.model.Specialist> getSpecialistDetails(String name,String type) {

        HospitalRoot hospitalRoot=hospitalDetailsClient.getSpecialistDetails(name,type);
        Hospitals hospitals=hospitalRoot.getHospitals();
        List<Hospital> hospitalList=hospitals.getHospital();
        int match=0;
        int matchList=0;
        List<com.assignment.hospital.resource.model.Specialist> specialistResponse=new ArrayList<>();
        for (Hospital hospital:hospitalList){
            if (hospital.getName().equals(name)){
                match=1;
                List<Specialist> specialistList=hospital.getSpecialists();
                for (Specialist specialist1:specialistList){
                    if(specialist1.getType().equals(type)){
                        matchList=1;
                        com.assignment.hospital.resource.model.Specialist specialist= new com.assignment.hospital.resource.model.Specialist();
                        BeanUtils.copyProperties(specialist1,specialist);
                        specialistResponse.add(specialist);
                    }

                }
            }
        }
        if (match!=1){
            throw  new DetailsNotFoundException("Invalid hospital name:    "+ name);
        }
        if (matchList!=1){
            throw new DetailsNotFoundException("Specialist details not found for hospital:"+name    +"of type:"    +type);
        }
        return specialistResponse;
    }
}
