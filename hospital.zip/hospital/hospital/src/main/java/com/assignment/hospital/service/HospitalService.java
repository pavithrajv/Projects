package com.assignment.hospital.service;


import com.assignment.hospital.resource.model.Specialist;

import java.util.List;

public interface HospitalService {
    List<Specialist> getSpecialistDetails(String name,String type);
}
