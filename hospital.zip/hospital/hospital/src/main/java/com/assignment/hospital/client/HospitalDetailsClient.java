package com.assignment.hospital.client;

import com.assignment.hospital.client.model.HospitalRoot;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

@Component
public class HospitalDetailsClient {
    public HospitalRoot getSpecialistDetails() {

        File file=new File("C:\\Users\\761282\\Downloads\\hospital\\hospital\\src\\main\\java\\com\\assignment\\hospital\\client\\hospital.json");
        ObjectMapper objectMapper = new ObjectMapper();
        HospitalRoot hospitalRoot= null;
        try {
            hospitalRoot= objectMapper.readValue(new FileInputStream(file), HospitalRoot.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return hospitalRoot;
    }
}
